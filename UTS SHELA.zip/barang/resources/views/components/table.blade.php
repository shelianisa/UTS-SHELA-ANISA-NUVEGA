<div class="row">
    <div class="col">
        <div class="mb-3">
            <label for="{{$isi1}}" class="form-label">{{$isi1}}</label>
            <input type="text" class="form-control" id="{{$isi1}}">
        </div>
    </div>
    <div class="col">
        <div class="mb-3">
            <label for="{{$isi2}}" class="form-label">{{$isi2}}</label>
            <input type="text" class="form-control" id="{{$isi2}}">
        </div>
    </div>
</div>