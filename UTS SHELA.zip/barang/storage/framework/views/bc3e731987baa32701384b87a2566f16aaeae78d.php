<h1>Daftar barang</h1>


<?php $__currentLoopData = $daftarBarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h2><?php echo e($barang->nama_barang); ?></h2>
    <p><?php echo e($barang->harga_barang); ?></p>
    <p><?php echo e($barang->tanggal_dan_waktu_pembelian); ?></p>
    <p><?php echo e($barang->kode_review_barang); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Users\USER\taufikz\barang\resources\views/home.blade.php ENDPATH**/ ?>