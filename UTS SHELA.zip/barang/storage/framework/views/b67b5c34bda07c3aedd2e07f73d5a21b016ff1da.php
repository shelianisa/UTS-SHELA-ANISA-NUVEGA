
<?php $__env->startSection('master'); ?>
<div class="container-fluid">
    <div class="container">
        <h1 class="text-center mb-5 mt-5">Daftar Harga Barang</h1>
        <div class="row justify-content-between">
            <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brg => $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-5" style="width: 18rem;">
                <img src="assets/<?php echo e($barang->fotoBarang); ?>" class="card-img-top" alt="...">
                <div class="card-body">
                    <h4><?php echo e($barang->namaBarang); ?></h4>
                    <h5>Rp <?php echo e($barang->harga); ?></h5>
                    <a href="<?php echo e(route('reviewBarang.view', $barang->id)); ?>" class="btn btn-success"> Detail Barang</a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\barang\resources\views/daftarBarang.blade.php ENDPATH**/ ?>